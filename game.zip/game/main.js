var canvas = document.createElement("canvas");
canvas.width = 755;
canvas.height = 463;
document.appendChild(canvas);
var ctx = canvas.getContext("2d");

var img = new Image();
img.onload = function()
{
	window.setInterval(function() 
	{
		ctx.drawImage(img,0,0);
	}, 16);

};
img.src = "bruce.jpg";


