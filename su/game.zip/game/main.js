(function() {

    function __CAAT__loadingScene(director) {

        var scene= director.createScene();

        var TIME= 500;
        var time= new Date().getTime();

        var background= new CAAT.ActorContainer().
            setBackgroundImage( director.getImage('splash'), false).
            setSize(director.width, director.height).
            setImageTransformation( CAAT.SpriteImage.prototype.TR_FIXED_TO_SIZE );
        scene.addChild(background);

        var lading= new CAAT.Actor().
                setBackgroundImage( director.getImage('lading'), true);
        lading.setLocation( director.width-lading.width-10, director.height-lading.height-30 );
        scene.addChild(lading);

        var rueda=  new CAAT.Actor().
                setBackgroundImage( director.getImage('rueda'), true).
                setLocation( lading.x+20, lading.y+10 );
        scene.addChild(rueda);
        rueda.addBehavior(
                new CAAT.RotateBehavior().
                        setValues(0,2*Math.PI).
                        setFrameTime(0,1000).
                        setCycle(true)
                );
        var starsImage= null;
        starsImage= new CAAT.SpriteImage().initialize(director.getImage('stars'), 24,6 );

        var T= 600;

        var mouseStars= function(mouseEvent) {

            for( var i=0; i<3; i++ ) {
                var offset0= Math.random()*10*(Math.random()<.5?1:-1);
                var offset1= Math.random()*10*(Math.random()<.5?1:-1);

                var iindex= (Math.random()*6)>>0;
                var actorStar= new CAAT.Actor();
                actorStar.__imageIndex= iindex;

                actorStar.
                        setBackgroundImage(
                            starsImage.getRef().setAnimationImageIndex( [(Math.random()*6)>>0] ), true ).
                        setLocation( offset0+mouseEvent.point.x, offset1+mouseEvent.point.y).
                        setDiscardable(true).
                        enableEvents(false).
                        setFrameTime(scene.time, T).
                        addBehavior(
                            new CAAT.ScaleBehavior().
                                setFrameTime(scene.time, T).
                                setValues( 1,5, 1,5 ).
                                setInterpolator(
                                    new CAAT.Interpolator().createExponentialInInterpolator(
                                        3,
                                        false)
                                )
                        ).
                        addBehavior(
                            new CAAT.GenericBehavior().
                                setFrameTime(scene.time, T).
                                setValues( 1, .1, null, null, function(value,target,actor) {
                                    actor.setSpriteIndex(
                                        actor.__imageIndex+(23-((23*value)>>0))*actor.backgroundImage.getColumns()
                                    );
                                }).
                                setInterpolator(
                                    new CAAT.Interpolator().createExponentialInInterpolator(
                                        3,
                                        false)) );

                background.addChild(actorStar);
            }
        };
        background.mouseMove= mouseStars;
        background.mouseDrag= mouseStars;

        scene.loadedImage = function(count, images) {

            if ( count===images.length ) {

                var difftime= new Date().getTime()-time;
                if ( difftime<TIME ){
                    difftime= Math.abs(TIME-difftime);
                    if ( difftime>TIME ) {
                        difftime= TIME;
                    }

                    scene.createTimer(
                        scene.time,
                        difftime,
                        function() {
                            __end_loading(director, images);
                        }
                    );

                } else {
                    __end_loading(director, images);
                }

            }
        };

        return scene;
    }

    function __end_loading(director, images) {

        director.emptyScenes();
        director.setImagesCache(images);

        createSolitaireScene(director);

        director.setScene(0);
    }

    function createSolitaireScene(director) {
        var scene= director.createScene();

        //new SU.FishPond().initialize(director,scene);

        //Math.seedrandom('paula');

        var model= new SU.Model().create(
            {
                numDecks:   1,      // number of decks
                maxRedeals: 0,      // unlimited
                cardsToDeal:3,      // take 3 cards from stock to waste

                waste:  {
                    visualHints: {
                        x:              150,
                        y:              50,
                        layout:         SU.Pile.Layout.NONE,
                        cardsShown:     3,
                        cardsDistance:  30,
                        image:          'A'
                    },
                    dragCondition : new SU.ConditionCardPositionInPile().
                        setType( SU.ConditionCardPositionInPile.Types.LAST_IN_PILE )
                },
                stock:  {
                    visualHints: {
                        x:              50,
                        y:              50,
                        layout:         SU.Pile.Layout.NONE,
                        cardsShown:     0,
                        cardsDistance:  30,
                        image:          'A'
                    }
                },
                tableau:    {
                    0:  {
                        dealSize:       1,
                        x:              50,
                        y:              200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:  30,
                        image:          'K'
                    },
                    1:  {
                        dealSize:   2,
                        x:          150,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:      30,
                        image:          'K'
                    },
                    2:  {
                        dealSize:   3,
                        x:          250,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:      30,
                        image:          'K'
                    },
                    3:  {
                        dealSize:   4,
                        x:          350,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:      30,
                        image:          'K'
                    },
                    4:  {
                        dealSize:   5,
                        x:          450,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:      30,
                        image:          'K'
                    },
                    5:  {
                        dealSize:   6,
                        x:          550,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:      30,
                        image:          'K'
                    },
                    6:  {
                        dealSize:   7,
                        x:          650,
                        y:          200,
                        layout:         SU.Pile.Layout.VERTICAL,
                        cardsDistance:  30,
                        image:          'K'
                    },
                    dragCondition:  new SU.ConditionAnd().
                            addCondition( new SU.ConditionCardIsVisible() ).
                            addCondition( new SU.ConditionCardSequence().setType(
                                SU.ConditionCardSequence.SequenceType.TOP_DOWN,
                                SU.ConditionCardSequence.SuitType.ALTERNATE_COLOR)
                            ),
                    dropCondition : new SU.ConditionPileMakeSequence().setType(
                            SU.ConditionPileMakeSequence.SequenceType.TOP_DOWN,
                            SU.ConditionPileMakeSequence.SuitType.ALTERNATE_COLOR,
                            1
                            )
                },
                foundation: {
                    0:  {
                        x:      350,
                        y:      50,
                        image:  'P',
                        layout: SU.Pile.Layout.NONE
                    },
                    1:  {
                        x:      450,
                        y:      50,
                        image:  'P',
                        layout: SU.Pile.Layout.NONE
                    },
                    2:  {
                        x:      550,
                        y:      50,
                        image:  'P',
                        layout: SU.Pile.Layout.NONE
                    },
                    3:  {
                        x:      650,
                        y:      50,
                        image:  'P',
                        layout: SU.Pile.Layout.NONE
                    },
                    dropCondition:
                        new SU.ConditionPileMakeSequence().setType(
                                SU.ConditionPileMakeSequence.SequenceType.BOTTOM_UP,
                                SU.ConditionPileMakeSequence.SuitType.EQUAL,
                                1
                        ),
                    dragCondition:
                        new SU.ConditionCardPositionInPile().setType(
                            SU.ConditionCardPositionInPile.Types.LAST_IN_PILE
                        )
                },
                transfer        :  {
                    visualHints: {
                            x:              0,
                            y:              0,
                            layout:         SU.Pile.Layout.VERTICAL,
                            cardsDistance:  30
                        }
                },
                autoplay        :  'tableau-foundation waste-foundation tableau-tableau waste-foundation deal',
                winCondition    :  new SU.ConditionWin()

            }
        ).shuffle();

        scene.addChild( new SU.ModelActor().initialize( director, scene, model ) );

        scene.createTimer(
            0,100,function()    {
                model.dealInit();
            }
        );
    }

    function ss() {

//        CAAT.DEBUG=1;

//        var director = new CAAT.Director().initialize(800,600,document.getElementById('game')).setClear(false);
//        director.enableResizeEvents(CAAT.Director.prototype.RESIZE_PROPORTIONAL);

        //var director = new CAAT.Director().initialize(800,600).setClear(false);
        var director = new CAAT.Director().initialize(800,600);
        document.getElementById('game').appendChild(director.canvas);

        CAAT.browser= navigator.browser;

        new CAAT.ImagePreloader().loadImages(
            [
                {id:'stars',    url:'game/res/stars.png'},
                {id:'splash',   url:'game/splash/splash.png'},
                {id:'lading',   url:'game/splash/lading.png'},
                {id:'rueda',    url:'game/splash/rueda.png'}
            ],
            function( counter, images ) {

                if ( counter===images.length ) {
                    director.setImagesCache(images);
                    var scene_loading= __CAAT__loadingScene(director);

                    new CAAT.ImagePreloader().loadImages(
                        [
                            {id:'cards',    url:'game/res/cartas.png'},
                            {id:'dorso',    url:'game/res/dorso.png'},
                            {id:'start',    url:'game/res/stars.png'},
                            {id:'K',        url:'game/res/rey.png'},
                            {id:'A',        url:'game/res/as.png'},
                            {id:'P',        url:'game/res/palos.png'}
                        ],

                        function( counter, images ) {
                            scene_loading.loadedImage(counter, images);
                        }
                    );

                }
            }
        );

        CAAT.loop(60);
    }

    window.addEventListener('load', ss, false);

})();