
// SU.PileActor
(function() {

    /**
     * @constructor
     */
    SU.PileActor= function()    {
        SU.PileActor.superclass.constructor.call(this);
        return this;
    };

    SU.PileActors= null;

    SU.PileActor.prototype= {

        pile                :   null,
        dorsoImage          :   null,
        model               :   null,
        horizontalLayout    :   false,

        initialize : function( model, pile, images )  {

            var t= SU.Pile.Type;

            this.dorsoImage=    images.dorso;
            this.model=         model;
            this.pile=          pile;

            switch( this.pile.visualHint.image )    {
                case 'A':
                    this.setBackgroundImage( images.A );
                    break;
                case 'K':
                    this.setBackgroundImage( images.K );
                    break;
                default:
                    this.setBackgroundImage( images.P );
            };

            this.pile.addListener( this.pileEvent.bind(this) );

            var p= this.getPileOnScreenPosition();
            this.setLocation( p.x, p.y );

            this.setSize( this.dorsoImage.width, this.dorsoImage.height );

            return this;
        },

        pileEvent : function( pile, action, data )  {
            if ( action==='card-added' )    {
                this.cardAdded( data.cards, data.fromPile );
            } else if ( action==='cards-to-be-added' ) {
                this.cardsToBeAdded( data.cards, data.fromPile );
            } else if ( action==='cards-added' ) {
                this.cardsAdded( data.cards, data.fromPile );
            } else if ( action==='removed' ) {
                this.cardsRemoved( data.cards, data.fromPile );
            }
        },

        cardsToBeAdded : function( cards, fromPile )    {

        },

        cardsAdded : function( cards, fromPile )  {
            this.parent.setZOrder(this, Number.MAX_VALUE);
        },

        cardsRemoved : function( cards, fromPile )  {

        },

        /**
         * Llamado despues de a�adir la carta al pile.
         * Si se sobreescirbe, ojo que tambien mueve la carta de pila.
         * @param card
         * @param fromPile
         */
        cardAdded : function( card, fromPile )  {

        },

        calcPileSize : function()   {
            // set new pile size.
            var rw= this.dorsoImage.width;
            var rh= this.dorsoImage.height;

            var pt= this.getNextCardPosition();

            this.setSize( rw + pt.x, rh + pt.y );
        },

        getPileOnScreenPosition : function()    {
            var vh= this.pile.visualHint;
            var x=0, y=0;

            if (vh) {
                x= vh.x;
                y= vh.y;
            }

            return  {
                x: x,
                y: y
            };
        },

        /**
         * Organiza (con animacion) las cartas dentro de un monton.
         * @param layout
         */
        layout : function() {

            var pile= this.pile;
            var vh= this.pile.visualHint;
            var l=  SU.Pile.Layout;
            var x= 0;
            var y= 0;
            var c;

            for( var i=0; i<pile.cards.length; i++ ) {
                c= SU.CardActors[ pile.cards[i].getName() ];

                c.__moveTo(
                    {
                        x: c.x,
                        y: c.y
                    },
                    {
                        x: x,
                        y: y
                    },
                    this.scene.time
                );

                switch( vh.layout ) {
                    case l.VERTICAL:
                        y+= vh.cardsDistance;
                        break;
                    case l.HORIZONTAL:
                        x+= vh.cardsDistance;
                        break;
                }
            }
        },

        unlayoutHorizontal : function() {
            this.setAlpha(0);
            this.setBackgroundImage( this.dorsoImage );
            this.horizontalLayout= false;
            var pos= this.getPileOnScreenPosition();
            this.setLocation( pos.x, pos.y ).calcPileSize();
            this.setModelViewMatrix(false);

            var ca;
            var ps_src_local;
            var pile= this.pile;

            for( var i=0; i<pile.cards.length; i++ ) {
                ca= SU.CardActors[ pile.cards[i].getName() ];
                ps_src_local= this.parent.modelToModel( new CAAT.Point(ca.x, ca.y ,0), this );
                ca.setLocation( ps_src_local.x, ps_src_local.y );
            }

            this.layout();

        },

        layoutHorizontal : function() {
            var pile= this.pile;

            this.parent.setZOrder(this,Number.MAX_VALUE);

            if ( this.horizontalLayout ) {
                this.unlayoutHorizontal();
            } else {

                var offset= 10;
                var w= this.backgroundImage.width+offset;
                var y= (this.parent.height - this.backgroundImage.height)/2;
                var x= (this.parent.width - (pile.cards.length-1)*w)/2 - w/2;

                if ( x<10 ) {
                    x=10;
                    w= (this.parent.width-20)/pile.cards.length;
                }

                var ca;
                var ps_src_local;

                for( var i=0; i<pile.cards.length; i++ ) {
                    ca= SU.CardActors[ pile.cards[i].getName() ];
                    ps_src_local= ca.modelToModel( new CAAT.Point(ca.x, ca.y ,0), this.parent );

                    ca.moveTo(
                        {
                            x: ps_src_local.x,
                            y: ps_src_local.y
                        },
                        {
                            x: x + w*i,
                            y: y
                        },
                        this.scene.time,
                        this.pile
                    );
                }

                this.setAlpha(.5);
                this.setBackgroundImage(null);
                this.setFillStyle('white');
                this.setBounds(0,0,this.parent.width,this.parent.height);
                this.horizontalLayout= true;
            }
        },

        getNextCardPosition : function()    {

            var vh= this.pile.visualHint;
            var l=  SU.Pile.Layout;
            var x= 0;
            var y= 0;

            switch( vh.layout ) {
                case l.VERTICAL:
                    y+= (this.pile.getSize()-1) * vh.cardsDistance;
                    break;
                case l.HORIZONTAL:
                    x+= (this.pile.getSize()-1) * vh.cardsDistance;
                    break;
            }

            return {
                x: x,
                y: y
            }
        },

        mouseClick : function(e) {
            if ( this.layoutHorizontal ) {
                this.unlayoutHorizontal();
            }
        }
    };

    extend( SU.PileActor, CAAT.ActorContainer );
})();

// SU.PileActorTableau
(function() {

    /**
     * @constructor
     */
    SU.PileActorTableau= function()    {
        SU.PileActorTableau.superclass.constructor.call(this);
        return this;
    };

    SU.PileActorTableau.prototype= {

        pile:       null,
        dorsoImage: null,
        model:      null,

        cardsAdded : function( addedCards, fromPile )    {

            SU.PileActorTableau.superclass.cardsAdded.call(this,addedCards,fromPile);

            var i;
            var pileFrom= SU.PileActors[ fromPile.getName() ];
            var ps_src_local;
            var cardActor= null;
            var index;

            SU.modelActor.readyIn( this.model.getActionCount()+addedCards.length );

            for( i=0; i<addedCards.length; i++ ) {
                cardActor= SU.CardActors[ addedCards[i].getName() ];
                ps_src_local= pileFrom.modelToModel( new CAAT.Point(cardActor.x, cardActor.y ,0), this );
                cardActor.setLocation(
                    ps_src_local.x,
                    ps_src_local.y );

                pileFrom.removeChild(cardActor);
                this.addChild(cardActor);

                index= this.findChild( cardActor );

                cardActor.moveTo(
                    {
                        x:cardActor.x,
                        y:cardActor.y
                    },
                    {
                        x: 0,
                        y: index*30
                    },
                    this.scene.time + (this.model.getActionCount()+i) * 50,
                    this.pile,
                    this.model.getStatus()===SU.Model.Status.DEALING );
            }

            this.calcPileSize();
        },

        cardsRemoved : function( cards, fromPile )  {

        },

        cardAdded : function( cards, fromPile ) {

        }

    };

    extend( SU.PileActorTableau, SU.PileActor );
})();

// SU.PileActorTransfer
(function() {

    /**
     * @constructor
     */
    SU.PileActorTransfer= function()   {
        SU.PileActorTransfer.superclass.constructor.call(this);
        this.visualHint= {
            layout: SU.Pile.Layout.NONE
        };

        return this;
    };

    SU.PileActorTransfer.prototype=    {

        setPositionAtCard : function( card ) {

            var cardActor= SU.CardActors[card.getName()];
            var pt= new CAAT.Point( 0,0 );
            cardActor.modelToView(pt);
            this.setLocation( pt.x, pt.y );
            this.setModelViewMatrix();
        },

        cardsToBeAdded : function( cards, fromPile )  {
            this.setPositionAtCard( cards[0] );
        },

        cardsAdded : function( addedCards, fromPile )    {
            SU.PileActorTransfer.superclass.cardsAdded.call(this,addedCards,fromPile);

            this.visualHint.layout= fromPile.visualHint.layout;
            this.visualHint.cardsDistance= fromPile.visualHint.cardsDistance;

            var i;
            var pileFrom= SU.PileActors[ fromPile.getName() ];
            var ps_src_local;
            var cardActor= null;
            var index;

            for( i=0; i<addedCards.length; i++ ) {
                cardActor= SU.CardActors[ addedCards[i].getName() ];
                ps_src_local= pileFrom.modelToModel( new CAAT.Point(cardActor.x, cardActor.y ,0), this );
                cardActor.setLocation(
                    ps_src_local.x,
                    ps_src_local.y );

                pileFrom.removeChild(cardActor);
                this.addChild(cardActor);

            }

            this.calcPileSize();


        },

        calcPileSize : function()   {

        },

        paint : function( director, time )  {
        }
    };

    extend( SU.PileActorTransfer, SU.PileActor );
})();

// SU.PileActorWaste
(function() {

    /**
     * @constructor
     */
    SU.PileActorWaste= function()   {
        SU.PileActorWaste.superclass.constructor.call(this);
        return this;
    };

    SU.PileActorWaste.prototype=    {

        doLayout : function(add) {
            var i;
            var pile= this.pile;
            var pileSize= this.pile.getSize();
            var card;
            var cardActor;

            // solo queremos 4 cartas visibles como mucho.
            if ( add ) {
                SU.modelActor.readyIn( 1 );
            }

            var vh= this.pile.visualHint;
            var nCards= vh.cardsShown;

            for( i=0; i<pileSize-nCards; i++ ) {
                card= pile.getCard(i);
                cardActor= SU.CardActors[ card.getName() ];
                if ( i<pileSize-2*nCards ) {
                    cardActor.setOutOfFrameTime();
                } else {
                    if ( cardActor.expired ) {
                        cardActor.setFrameTime( this.scene.time, Number.MAX_VALUE );
                        cardActor.setLocation(0,0);
                    }
                    cardActor.moveTo(
                        {
                            x:cardActor.x,
                            y:cardActor.y
                        },
                        {
                            x: 0,
                            y: 0
                        },
                        this.scene.time,
                        this.pile );
                    cardActor.BL_HideCard();
                }
            }

            var index= Math.min(nCards,pileSize);
            for( i=0; i<index; i++ )    {
                card= pile.getCard( pileSize-index+i );
                cardActor= SU.CardActors[ card.getName() ];
                if ( cardActor.expired ) {
                    cardActor.setFrameTime( this.scene.time, Number.MAX_VALUE );
                }
                cardActor.moveTo(
                    {
                        x:cardActor.x,
                        y:cardActor.y
                    },
                    {
                        x: i*vh.cardsDistance,
                        y: 0
                    },
                    this.scene.time,
                    this.pile );
                cardActor.BL_Nothing();
            }
        },

        cardsAdded : function( addedCards, fromPile )    {

            SU.PileActorWaste.superclass.cardsAdded.call(this,addedCards,fromPile);

            var i;
            var pileFrom= SU.PileActors[ fromPile.getName() ];
            var ps_src_local= pileFrom.modelToModel( new CAAT.Point(0,0,0), this );
            var cardActor= null;

            for( i=0; i<addedCards.length; i++ ) {
                cardActor= SU.CardActors[ addedCards[i].getName() ]; //pileFrom.getActorFor( addedCards[i] );
                cardActor.setLocation(
                    ps_src_local.x,
                    ps_src_local.y );

                pileFrom.removeChild(cardActor);
                this.addChild(cardActor);
            }

            this.doLayout(true);
            this.calcPileSize();
        },

        cardsRemoved : function( removedCards ) {
            this.doLayout(false);
            this.calcPileSize();
        },

        calcPileSize : function()   {
            // set new pile size.
            var rw= this.dorsoImage.width;
            var rh= this.dorsoImage.height;
            var vh= this.pile.visualHint;
            var s=  Math.min( 3, this.pile.getSize() );

            if ( vh.layout===SU.Pile )    {
                rh+= s * (vh.cardsDistance ? vh.cardsDistance : 30);
            } else {
                rw+= s * (vh.cardsDistance ? vh.cardsDistance : 30);
            }

            this.setSize( rw, rh );

        },

        cardAdded : function( cards, fromPile ) {

        },

        getNextCardPosition : function()    {

            var vh= this.pile.visualHint;
            var x= 0;
            var y= 0;

            var s= Math.min(3,this.pile.getSize());

            if ( vh.verticalLayout )    {
                y+= s * (vh.cardsDistance ? vh.cardsDistance : 30);
            } else {
                x+= s * (vh.cardsDistance ? vh.cardsDistance : 30);
            }

            return {
                x: x,
                y: y
            }
        }
    };

    extend( SU.PileActorWaste, SU.PileActor );
})();

// SU.PileActorStock
(function() {

    /**
     * @constructor
     */
    SU.PileActorStock= function()   {
        SU.PileActorStock.superclass.constructor.call(this);
        return this;
    };

    SU.PileActorStock.prototype= {

        NC:         3,
        CARD_OFFSET:5,


        cardsAdded : function( addedCards, fromPile )  {

            // BUGBUG
            // tener en cuenta cuantas cartas se a�aden, y cuantas habia antes de a�adir ninguna.
            
            SU.PileActorStock.superclass.cardsAdded.call(this,addedCards,fromPile);

            var i;
            var pileFromActor= SU.PileActors[ fromPile.getName() ];
            var pt_src_local;
            var cardActor= null;
            var offset= 0;
            var pileSize= this.pile.getSize();
            var card;

            SU.modelActor.readyIn( addedCards.length );


            // recoger cartas visibles.
            var cartas_a_mover= Math.min( addedCards.length, this.NC-1 );

            for( i=0; i<this.NC - cartas_a_mover; i++ ) {

                card= this.pile.getCard(-i - addedCards.length - 1);
                cardActor= SU.CardActors[ card.getName() ];
                cardActor.setFrameTime(this.scene.time, Number.MAX_VALUE);
                cardActor.moveTo(
                    {
                        x: cardActor.x,
                        y: cardActor.y
                    },
                    {
                        x: cardActor.x - this.CARD_OFFSET * cartas_a_mover,
                        y: 0
                    },
                    this.scene.time,
                    this.pile
                    );
            }


            for( i=0; i<addedCards.length; i++ ) {
                cardActor= SU.CardActors[ addedCards[i].getName() ];

                offset= i<addedCards.length-this.NC ?
                    0 :
                    (1-addedCards.length+i);

                pt_src_local= pileFromActor.modelToModel( new CAAT.Point( cardActor.x, cardActor.y, 0), this );
                cardActor.moveTo(
                    pt_src_local,
                    {
                        x: offset*this.CARD_OFFSET,
                        y: 0
                    },
                    this.scene.time + i*50,
                    this.pile
                    );

                if ( i<addedCards.length- this.NC ) {
                    cardActor.BL_HideCard( );
                } else {
                    cardActor.BL_Nothing( );
                }

                pileFromActor.removeChild(cardActor);

                // a�adir detr�s del cosm�tico de pulsaci�n.
                this.addChild(cardActor);

            }

        },

        cardAdded : function( cards, fromPile )    {

        },

        cardsRemoved : function( removedCards ) {
            var i;
            var pile= this.pile;
            var pileSize= this.pile.getSize();
            var card;
            var cardActor;

            var index= Math.max(0,pileSize-this.NC);

            for( i=0; i<index; i++ ) {
                card= pile.getCard(i);
                cardActor= SU.CardActors[ card.getName() ];

                if ( i===index-1 ) {
                    cardActor.setFrameTime(this.scene.time, Number.MAX_VALUE);
                    cardActor.setLocation( -(this.NC-1)*this.CARD_OFFSET, 0 );
                } else {
                    cardActor.setOutOfFrameTime();
                }
            }

            // si hay menos elementos que los que esperamos visibles, hay que reorganizar los elementos hacia
            // la derecha
            var rem= Math.min( this.NC, pileSize );
            for( i=0; i<rem; i++ ) {
                // cartas desde arriba
                card= pile.getCard(-i-1);
                cardActor= SU.CardActors[ card.getName() ];

                    var pt_src_local= new CAAT.Point( cardActor.x, cardActor.y, 0);
                    cardActor.setFrameTime( this.scene.time, Number.MAX_VALUE );
                    var offset= i;
                    //cardActor.setLocation(offset*this.CARD_OFFSET,0);
                    cardActor.moveTo(
                        pt_src_local,
                        {
                            x: -offset*this.CARD_OFFSET,
                            y: 0
                        },
                        this.scene.time,
                        this.pile
                        );
                    cardActor.BL_Nothing();
            }
        }

    };

    extend( SU.PileActorStock, SU.PileActor );

})();

//SU.PileActorFoundation
(function() {
    SU.PileActorFoundation= function()  {
        SU.PileActorFoundation.superclass.constructor.call(this);
        return this;
    };

    SU.PileActorFoundation.prototype=   {

        doLayout : function() {
            var i;
            var pile= this.pile;
            var pileSize= this.pile.getSize();
            var card;
            var cardActor;

            for( i=0; i<pileSize-2; i++ ) {
                card= pile.getCard(i);
                cardActor= SU.CardActors[ card.getName() ];
                cardActor.setOutOfFrameTime();
            }

            var index= Math.min(2,pileSize);

            SU.modelActor.readyIn( 1 );

            for( i=0; i<index; i++ )    {
                card= pile.getCard( pileSize-index+i );
                cardActor= SU.CardActors[ card.getName() ];
                cardActor.setFrameTime( this.scene.time, Number.MAX_VALUE );
                cardActor.moveTo(
                    {
                        x:cardActor.x,
                        y:cardActor.y
                    },
                    {
                        x: 0,
                        y: 0
                    },
                    this.scene.time,
                    this.pile,
                    false );
            }
        },

        cardsAdded : function( addedCards, fromPile )    {

            SU.PileActorFoundation.superclass.cardsAdded.call(this,addedCards,fromPile);

            var i;
            var pileFrom= SU.PileActors[ fromPile.getName() ];
            var ps_src_local= pileFrom.modelToModel( new CAAT.Point(0,0,0), this );
            var cardActor= null;

            for( i=0; i<addedCards.length; i++ ) {
                cardActor= SU.CardActors[ addedCards[i].getName() ]; //pileFrom.getActorFor( addedCards[i] );
                cardActor.setLocation(
                    ps_src_local.x,
                    ps_src_local.y );

                pileFrom.removeChild(cardActor);
                this.addChild(cardActor);
            }

            this.doLayout();
            this.calcPileSize();
        },

        cardsRemoved : function( removedCards ) {
            this.doLayout();
            this.calcPileSize();
        },

        calcPileSize : function()   {
            // set new pile size.
            var rw= this.dorsoImage.width;
            var rh= this.dorsoImage.height;

            this.setSize( rw, rh );

        },

        cardAdded : function( cards, fromPile ) {

        }
    };

    extend( SU.PileActorFoundation, SU.PileActor );

})();

// SU.CardActor
(function() {

    /**
     * @constructor
     */
    SU.CardActor= function()    {
        SU.CardActor.superclass.constructor.call(this);
        this.setId(512);
        return this;
    };

    SU.CardActor.BEHAVIOR_TIME= 600;
    SU.CardActor.BEHAVIOR_VISIBILITY_TIME= 200;
    SU.CardActor.NEXT_ANIMATION_DELAY= 50;

    SU.CardActor.prototype= {

        card :          null,
        imageIndex:     0,
        cardImage:      null,
        dorsoImage:     null,
        scene:          null,
        model:          null,
        bshow:          null,
        bhide:          null,

        canDrag:        false,
        dragPrevX:      -1,
        dragPrevY:      -1,


        pile2Actor:     null,

        /**
         *
         * @param card {SU.Card}
         * @param cardImage {CAAT.SpriteImage}
         */
        initialize : function(scene, model, card, cardImage, dorsoImage, pile2Actor) {
            this.card=          card;
            this.cardImage=     cardImage;
            this.scene=         scene;
            this.model=         model;
            this.dorsoImage=    dorsoImage;
            this.pile2Actor=    pile2Actor;
            this.imageIndex=    (card.getIndex()-1)*4 + card.getSuitId();
                                //(card.getIndex()-1) + card.getSuitId() * 13;
            
            this.setBackgroundImage( dorsoImage, true );

            card.addListener( this.cardListener.bind(this) );

            this.setOutOfFrameTime();

            return this;
        },

        /**
         * Show compact selection format
         * @param e
         */
        mouseClick : function(e) {
            if ( this.parent.pile.getType()===SU.Pile.Type.TABLEAU ) {
                this.parent.layoutHorizontal();
            }
        },

        mouseDblClick : function(e) {
            if ( this.card.isLastInPile() ) {
                this.model.autoFoundation(this.card);
            }
        },

        /**
         *
         * @param e {CAAT.MouseEvent}
         */
        mouseEnter : function(e)   {
            if ( this.canDrag ) {
                CAAT.setCursor('pointer');
            }
        },

        /**
         *
         * @param e {CAAT.MouseEvent}
         */
        mouseExit : function(e) {
            CAAT.setCursor('default');
        },

        mouseDown : function(e) {
            if ( this.canDrag ) {

                this.model.drag(this.card);

                this.dragPrevX= e.screenPoint.x;
                this.dragPrevY= e.screenPoint.y;
            }
        },

        mouseUp : function(e)   {
            this.dragPrevX= -1;
            this.dragPrevY= -1;
            // was dragging
            if ( this.canDrag ) {
                // mirar a ver si se suelta transfer sobre una pila concreta.
                // si es asi, transfer.
                var dropTarget= this.checkPositionWithDropTargets();
                this.model.drop( dropTarget ? dropTarget.pile : null );
            }
        },

        mouseDrag : function(e) {
            if ( this.canDrag ) {

                /**
                 * Si la carta pertenecia a un monton que esta organizado horizontalmente,
                 * hacer una animaci�n para llevar las cartas no seleccionadas al origen, y
                 * otra para llevar las cartas del transfer a su posici�n ordenada.
                 */
                var currentTR= this.model.getCurrentTransferSource();
                if ( currentTR.getType()===SU.Pile.Type.TABLEAU ) {
                    var pa= SU.PileActors[currentTR.getName()];
                    if ( pa.horizontalLayout ) {
                        pa.unlayoutHorizontal();
                        
                        SU.PileActors[this.parent.pile.getName()].layout( );
                    }
                }

                var sp= e.screenPoint;
                var parent= this.parent;
                var x= parent.x + sp.x - this.dragPrevX;
                var y= parent.y + sp.y - this.dragPrevY;
                parent.setLocation(x,y);
                this.dragPrevX= sp.x;
                this.dragPrevY= sp.y;

                //this.checkPositionWithDropTargets();
            }
        },

        /**
         * Comprueba para los targets de drop validos, si tenemos las esquinas superiores
         * un 30% dentro de su area.
         */
        checkPositionWithDropTargets : function()   {
            var i;
            var pile;
            var pileActor;
            var dropTargets=        this.model.validDropTargets;
            var pileActorTransfer=  this.parent;
            var x,y;

            for (i = 0; i < dropTargets.length; i++) {
                pile= dropTargets[i];
                pileActor= SU.PileActors[ pile.getName() ];

                x= pileActorTransfer.x - pileActor.x;
                y= pileActorTransfer.y - pileActor.y;

                x/= pileActor.width;
                y/= pileActor.height;

                //dentro un 20%
                if ( x>=0 && x<=1 && y>=0 && y<=1 ) {
                    return pileActor;
                }
            }

            return null;
        },

        /**
         *
         * @param card {SU.Card}
         * @param eventType{string}
         * @param data{object}
         */
        cardListener : function( card, eventType, data )  {
            if ( eventType==='visibilityChange' )    {
                this.setVisibility(data);
            } else if ( eventType==='dragInfo' ) {
                this.canDrag= data;
            } else if ( eventType==='dealInit' ) {
                
            }
        },

        setVisibility : function(show)  {

            var pb= this.getBehavior( 101 );
            var me= this;

            if ( !pb )  {
                
                pb= new CAAT.ContainerBehavior().setId(101);

                this.bshow= new CAAT.ScaleBehavior().
                    setValues( 0,1, 1.1,1 ).
                    setFrameTime( SU.CardActor.BEHAVIOR_VISIBILITY_TIME/2, SU.CardActor.BEHAVIOR_VISIBILITY_TIME/2 );
                this.bhide= new CAAT.ScaleBehavior().
                    setValues( 1,0, 1,1.1 ).
                    setFrameTime( 0, SU.CardActor.BEHAVIOR_VISIBILITY_TIME/2 );

                pb.addBehavior( this.bhide );
                pb.addBehavior( this.bshow );

                this.addBehavior(pb);
            }

            if ( show )  {
                me.setBackgroundImage( me.dorsoImage );
                this.bhide.emptyListenerList();
                this.bhide.addListener({
                    behaviorExpired : function()    {
                        me.setBackgroundImage( me.cardImage );
                        me.setSpriteIndex( me.imageIndex );
                    }
                });
            } else {
                me.setBackgroundImage( me.cardImage );
                me.setSpriteIndex( me.imageIndex );
                this.bhide.emptyListenerList();
                this.bhide.addListener({
                    behaviorExpired : function()    {
                        me.setBackgroundImage( me.dorsoImage );
                    }
                });
            }

            pb.setFrameTime(
                this.scene.time + (this.model.getActionCount()-1) * SU.CardActor.NEXT_ANIMATION_DELAY +
                    (show ? SU.CardActor.BEHAVIOR_TIME - SU.CardActor.BEHAVIOR_VISIBILITY_TIME : 0 ),
                SU.CardActor.BEHAVIOR_VISIBILITY_TIME );
        },

        BL_Nothing : function() {
            var b0= this.getBehavior(100);
            b0.emptyListenerList();
        },

        BL_HideCard : function(callback)    {
            var me= this;
            var b0= this.getBehavior(100);
            b0.emptyListenerList();
            b0.addListener( {
                behaviorExpired : function(behavior,time,actor) {
                    actor.setOutOfFrameTime();
                    actor.getBehavior(100).emptyListenerList();
                    if ( callback ) {
                        callback();
                    }
                }
            });
        },

        moveTo : function( pt_src_local, pt_dst_local, start_time, toPile, rotate )  {
            this.setLocation( pt_src_local.x, pt_src_local.y );

            if ( toPile.getType()!==SU.Pile.Type.TRANSFER ) {
                var b1= this.getBehavior( 102 );

                if ( this.expired ) {
                    this.setFrameTime( start_time, Number.MAX_VALUE );
                }

                if ( rotate && toPile.getType()!==SU.Pile.Type.WASTE && toPile.getType()!==SU.Pile.Type.STOCK ) {
                    if ( null===b1 )    {
                        b1= new CAAT.RotateBehavior().
                            setValues( 0, 2*(Math.random()<.5 ? 1: 2)*Math.PI ).
                            setId(102).
                            setInterpolator( new CAAT.Interpolator().createExponentialOutInterpolator(3,false) );
                        this.addBehavior( b1 );
                    }

                    b1.setFrameTime( start_time, SU.CardActor.BEHAVIOR_TIME );
                }

                this.__moveTo( pt_src_local, pt_dst_local, start_time );

            } else {
                this.setLocation( pt_dst_local.x, pt_dst_local.y );
            }
        },

        __moveTo : function( pt_src_local, pt_dst_local, start_time ) {
            var b0= this.getBehavior( 100 );

            if ( !b0 ){
                b0= new CAAT.PathBehavior().
                    setValues( new CAAT.Path().setLinear( 0,0,0,0 ) ).
                    setId(100).
                    setInterpolator( new CAAT.Interpolator().createExponentialOutInterpolator(3,false) );
                this.addBehavior( b0 );
            }
            if ( pt_src_local.x!=pt_dst_local.x || pt_src_local.y!=pt_dst_local.y ) {
                b0.setValues(
                    new CAAT.Path().setLinear(
                        pt_src_local.x,
                        pt_src_local.y,
                        pt_dst_local.x,
                        pt_dst_local.y )
                ).setFrameTime( start_time, SU.CardActor.BEHAVIOR_TIME );
            }

        }
    };

    extend( SU.CardActor, CAAT.Actor );

})();

// SU.ModelActor
(function() {

    SU.ModelActor= function()   {
        SU.ModelActor.superclass.constructor.call(this);
        return this;
    };

    SU.ModelActor.prototype=    {
        model           :   null,
        stockActor:         null,
        wasteActor:         null,
        transferActor:      null,
        foundationActors:   null,
        tableauActors:      null,

        pile2Actor:         null,

        scene:              null,

        initialize : function(director, scene, model)    {
            this.model= model;

            this.model.addListener( this.modelEvent.bind(this) );

            this.scene= scene;
            this.setSize( director.width, director.height );

            SU.modelActor= this;
            
            this.pile2Actor=    {};

            var cardsImage= new CAAT.SpriteImage().initialize( director.getImage('cards'), 13, 4 );
            var images= {
                dorso: director.getImage('dorso'),
                A:      director.getImage('A'),
                K:      director.getImage('K'),
                P:      director.getImage('P')
            };
            var i;
            var tp;
            var fp;

            this.stockActor= new SU.PileActorStock().initialize( model, model.getStockPile(), images ).enableEvents(false);
            this.addChild( this.stockActor );

                var cardActor= new CAAT.Actor().setBounds( this.stockActor.x, this.stockActor.y, images.dorso.width, images.dorso.height );

                cardActor.mouseEnter= function(e)    {
                    CAAT.setCursor('pointer');
                };

                cardActor.mouseExit= function(e) {
                    CAAT.setCursor('default');
                };

                cardActor.mouseClick= function(e)    {
                    model.deal();
                    return this;
                };

                this.addChild( cardActor );


            this.pile2Actor[ model.getStockPile().getName() ]= this.stockActor;

            this.wasteActor= new SU.PileActorWaste().initialize( model, model.getWastePile(), images );
            this.addChild( this.wasteActor );
            this.pile2Actor[ model.getWastePile().getName() ]= this.wasteActor;

            tp= model.getTableauPiles();
            this.tableauActors= [];
            for( i=0; i<tp.length; i++ )    {
                this.tableauActors.push(
                    new SU.PileActorTableau()
                        .initialize( model, tp[i], images )
                );
                this.addChild( this.tableauActors[i] );
                this.pile2Actor[ tp[i].getName() ]= this.tableauActors[i];
            }

            fp= model.getFoundationPiles();
            this.foundationActors= [];
            for( i=0; i<fp.length; i++ )    {
                this.foundationActors.push(
                    new SU.PileActorFoundation().initialize( model, fp[i], images ) );
                this.addChild( this.foundationActors[i] );
                this.pile2Actor[ fp[i].getName() ]= this.foundationActors[i];
            }

            this.transferActor= new SU.PileActorTransfer().
                initialize( model, model.getTransferPile(), images ).
                enableEvents( false );
            this.addChild( this.transferActor );
            this.pile2Actor[ model.getTransferPile().getName() ]= this.transferActor;

            SU.PileActors= this.pile2Actor;

            SU.PileActor.prototype.scene= scene;

            var card2Actor= {};
            for( i=0; i<model.getSize(); i++ )  {
                var card= model.getCard(i);
                var cardActor= new SU.CardActor().initialize(
                    scene,
                    model,
                    card,
                    cardsImage.getRef(),
                    images.dorso,
                    this.pile2Actor );
                this.stockActor.addChild( cardActor );

                card2Actor[card.getName()]= cardActor;
            }

            SU.CardActors= card2Actor;

            var undo= new CAAT.Actor().
                setFillStyle('green').
                setAsButton( images.dorso,0,0,0,0,function(button) {

                    model.undo();
                }).
                setBounds(director.width-30,0,30,30).
                setImageTransformation( CAAT.SpriteImage.prototype.TR_FIXED_TO_SIZE );
            this.addChild(undo);


            return this;
        },

        modelEvent : function( event, data ) {
            if ( event==='dealInit' ) {
                var me= this;
                var t= SU.CardActor.BEHAVIOR_TIME + SU.CardActor.NEXT_ANIMATION_DELAY*(data.actions-1);
                setTimeout(
                    function() {
                        me.model.ready();
                    },
                    t );
            } else if ( event==='status' ) {
                this.scene.enableEvents( data===SU.Model.Status.USER );

                if ( data===SU.Model.Status.WIN ) {
                    this.gameWin();
                } else if ( data===SU.Model.Status.ENDED ) {
                    this.gameEnded();
                }
            }
        },

        readyIn : function( actions ) {
            if ( !actions ) {
                return;
            }

            var me= this;
            if ( this.model.getStatus()===SU.Model.Status.USER || this.model.getStatus()===SU.Model.Status.AUTOMATIC ) {

                this.model.setStatus( SU.Model.Status.ANIMATION );

                var t= SU.CardActor.BEHAVIOR_TIME + actions*SU.CardActor.NEXT_ANIMATION_DELAY;
                setTimeout(
                    function() {
                        me.model.ready();
                    },
                    t );
            }
        },

        gameWin : function() {
console.log('win');
        },

        gameEnded : function() {
console.log('end');
        }
    };

    extend( SU.ModelActor, CAAT.ActorContainer );

})();